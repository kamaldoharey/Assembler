import assembler.*;

public class Calling {

	public static void main(String[] args) {
		Assembler obj = new Assembler();
		obj.passOne();
		obj.passTwo();
	}

}
